package org.exam.Oopsproject1.Screen;

public interface ScreenInterface {

	
	public void MainMenu();
    public void MenuOption(int option);    
    public void InputFromUser();

}
