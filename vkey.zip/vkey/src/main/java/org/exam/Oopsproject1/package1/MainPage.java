package org.exam.Oopsproject1.package1;

import org.exam.Oopsproject1.Screen.HomeScreen;

public class MainPage {

	public static void main(String[] args) {
		
         HomeScreen home = new HomeScreen();
    	
    	System.out.println("Project Name: VirtualKey");
    	System.out.println("Developer Name: somita dubey");
       
    	home.MenuList();
    	home.InputFromUser();


	}

}
