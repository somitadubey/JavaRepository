package org.exam.Oopsproject1.PackageService;


	import org.exam.Oopsproject1.Entities.FileDirectory;
import org.exam.Oopsproject1.Screen.FileScreen;
import org.exam.Oopsproject1.Screen.HomeScreen;
import org.exam.Oopsproject1.Screen.ScreenInterface;


	public class FileService {
		
		public static HomeScreen HomeScreen = new HomeScreen();
	    public static FileScreen FileScreen = new FileScreen();    
	    
	    public static ScreenInterface CurrentScreen = HomeScreen;

	    
	    public static ScreenInterface getCurrentScreen() {
	        return CurrentScreen;
	    }

	    
	    public static void setCurrentScreen(ScreenInterface currentScreen) {
	        CurrentScreen = currentScreen;
	    }
	    
	    
	    
	}



